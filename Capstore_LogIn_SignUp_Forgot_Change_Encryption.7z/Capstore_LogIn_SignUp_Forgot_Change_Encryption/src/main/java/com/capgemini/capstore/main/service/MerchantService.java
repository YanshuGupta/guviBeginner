package com.capgemini.capstore.main.service;

import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.main.beans.Customer;
import com.capgemini.capstore.main.beans.Merchant;
import com.capgemini.capstore.main.beans.MerchantProduct;
import com.capgemini.capstore.main.beans.User;
import com.capgemini.capstore.main.dao.CapStoreCustomer;
import com.capgemini.capstore.main.dao.CapStoreMerchant;
import com.capgemini.capstore.main.dao.CapStoreUser;
import com.capgemini.capstore.main.exception.InvalidLogInCredential;

@Service
public class MerchantService implements IMerchantService{

	@Autowired
	CapStoreMerchant merchantRepo;
	
	@Autowired
	CapStoreCustomer customerRepo;
	
	@Autowired
	CapStoreUser userRepo;

	@Override
	public boolean ValidateLogIn(User user) {

		User result;
		try {
		result = userRepo.findById(user.getEmailId()).get();
		}catch (Exception e) {
			return false;
		}
		if(result != null){
			MD5 encryption = new MD5();
			user.setPassword(encryption.encryptText(user.getPassword()));
			if(result.equals(user)) {
				return true;
			}
			return false;
		}
		return false;
	}

	@Override
	public Merchant getMerchant(int merchantId) {
		return merchantRepo.getOne(merchantId);
	}

	@Override
	public boolean ValidateUserDetails(@Valid User user) {
		MD5 encryption = new MD5();
		user.setPassword(encryption.encryptText(user.getPassword()));
		Optional<User> result = userRepo.findById(user.getEmailId());
		if(result.isPresent()){
			return false;
		}
		userRepo.save(user);
		return true;
	}

	@Override
	public Customer ValidateCustomerDetails(@Valid Customer customer) {
		return customerRepo.save(customer);
	}

	@Override
	public Merchant ValidateMerchantDetails(@Valid Merchant merchant) {
		return merchantRepo.save(merchant);
	}

	@Override
	public boolean isValidResetPasswordRequest(String email) {
		
		
		return false;
	}

	@Override
	public String isValidEmail(String email) {
		try {
			User user = userRepo.findById(email).get();
			return user.getSecurityQuestion();
		}
		catch (Exception e) {
			return null;
		}
	}
	
	@Override
	public boolean checkSequirityAnswer(String email, String sequirityAnswer) {
		try {
			User user = userRepo.findById(email).get();
			if(user.getSecurityAnswer().equalsIgnoreCase(sequirityAnswer)) {
				return true;
			}
			return false;
		}
		catch (Exception e) {
			return false;
		}
	}
	
	@Override
	public void updatePassword(String email, String password) {
		MD5 encryption = new MD5();
		password = encryption.encryptText(password);
		try {
			User user = userRepo.findById(email).get();
			user.setPassword(password);
			userRepo.save(user);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public boolean changePassword(String email, String oldPassword, String newPassword) {
		MD5 encryption = new MD5();
		oldPassword = encryption.encryptText(oldPassword);
		newPassword = encryption.encryptText(newPassword);
		try {
			User user = userRepo.findById(email).get();
			if(user.getPassword().equals(oldPassword)) {
				user.setPassword(newPassword);
				userRepo.save(user);
				return true;
			}
			return false;
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}
	
}
